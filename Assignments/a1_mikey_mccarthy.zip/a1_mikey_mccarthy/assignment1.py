# ITP 115, Fall 2023
# Assignment 1
# Name: Mikey McCarthy
# Email: mtmccart@usc.edu
# Section:31870
# Description;
   # This program creates variables with information about myself and
   # displays to the user.
firstname = "Mikey"
lastname = "McCarthy"
major = "Data Science"
month = 6
day = 20
year = 2003
coder = True
print("My full name is " + firstname + " " + lastname)
print("My major is " + major)
print("My Birthday is", month, "/", day, "/", year)
print("I'm a coder is ", coder)